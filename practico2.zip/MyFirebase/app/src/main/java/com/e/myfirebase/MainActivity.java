package com.e.myfirebase;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.e.myfirebase.model.Persona;
import com.e.myfirebase.model.Heroe;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    Spinner opciones_heroes;
    Spinner segmento_personas;


    private List<Persona> listPerson = new ArrayList<Persona>();
    ArrayAdapter<Persona> arrayAdapterPersona;

    EditText txtGusto, txtCambio, txtAparicion;
    ListView listV_personas;

    //PARAMETROS PARA TRABAJAR CON FIREBASE---------------------------------
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        segmento_personas = (Spinner) findViewById(R.id.id_spiner_segmento);
        ArrayAdapter<CharSequence> adapt = arrayAdapterPersona.createFromResource(this, R.array.SegmentoPersonas, android.R.layout.simple_spinner_item);
        segmento_personas.setAdapter(adapt);


        opciones_heroes = (Spinner) findViewById(R.id.id_spiner_heroes);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.MarvelHeroes, android.R.layout.simple_spinner_item);
        opciones_heroes.setAdapter(adapter);


        txtGusto = findViewById(R.id.txt_gusto);
        txtCambio = findViewById(R.id.txt_cambio);
        txtAparicion = findViewById(R.id.txt_aparicion);


        listV_personas = findViewById(R.id.lv_datosPersonas);
        inicializarFirebase();
        listarDatos();
    }

    //VISUALIZACION DE DATOS -----------------------------------------------------
    private void listarDatos() {
        databaseReference.child("Persona").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listPerson.clear();
                for (DataSnapshot objSnaptshot : dataSnapshot.getChildren()) {
                    Persona p = objSnaptshot.getValue(Persona.class);
                    listPerson.add(p);

                    arrayAdapterPersona = new ArrayAdapter<Persona>(MainActivity.this, android.R.layout.simple_list_item_1, listPerson);
                    listV_personas.setAdapter(arrayAdapterPersona);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //INICIALIZAR FIREBASE----------------------------------------------
    private void inicializarFirebase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String tGusto = txtGusto.getText().toString();
        String tCambio = txtCambio.getText().toString();
        String tAparicion = txtAparicion.getText().toString();

        switch (item.getItemId()) {
            case R.id.icon_add: {
                if (tGusto.equals("") || tCambio.equals("") || tAparicion.equals("")) {
                    validacion();
                } else {
                    Heroe p = new Heroe();
                    p.setUid(UUID.randomUUID().toString());
                    p.setGusto(tGusto);
                    p.setCambio(tCambio);
                    p.setAparicion(tAparicion);
                    databaseReference.child("Encuesta").child(p.getUid()).setValue(p);
                    Toast.makeText(this, "Agregado", Toast.LENGTH_LONG).show();
                    refrescarBoxes();
                    break;
                }
            }
            case R.id.icon_save: {
                Toast.makeText(this, "Guardar", Toast.LENGTH_LONG).show();
                break;
            }

            case R.id.icon_delete: {
                Toast.makeText(this, "Eliminar", Toast.LENGTH_LONG).show();
                break;
            }

            default:
                break;
        }
        return true;
    }

    private void validacion() {
        String gusto = txtGusto.getText().toString();
        String cambio = txtCambio.getText().toString();
        String aparicion = txtAparicion.getText().toString();

        if (gusto.equals("")) {
            txtGusto.setError("Required");
        }

        if (cambio.equals("")) {
            txtCambio.setError("Required");
        }

        if (aparicion.equals("")) {
            txtAparicion.setError("Required");
        }

    }

    private void refrescarBoxes() {
        txtGusto.setText("");
        txtCambio.setText("");
        txtAparicion.setText("");

    }
}
